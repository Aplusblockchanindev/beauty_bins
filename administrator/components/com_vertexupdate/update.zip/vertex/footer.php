<?php
// NOTE - You may change this file to suit your site needs
?>
<span class="footerc">
Copyright &copy; <?php echo $s5_cur_year;?>.  <?php echo $s5_csite_name;?>.
Designed by Shape5.com <a href="http://www.shape5.com/" title="Visit Shape5.com Joomla Template Club" target="blank" class="footerc">Joomla Templates</a>
</span>
