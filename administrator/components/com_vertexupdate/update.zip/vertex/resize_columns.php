<script type="text/javascript">//<![CDATA[
	var s5_resize_columns_browser_check = "<?php echo $browser; ?>";
	var s5_resize_columns = "<?php echo $s5_resize_columns; ?>";
	var s5_resize_columns_delay = "<?php echo $s5_resize_columns_delay; ?>";
	var s5_resize_columns_small_tablets = "<?php echo $s5_responsive_columns_small_tablet; ?>";
//]]></script>
<script type="text/javascript" src="<?php echo $s5_directory_path ?>/js/core/s5_columns_equalizer-min.js"></script>